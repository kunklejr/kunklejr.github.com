package com.nearinfinity.logguard;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class IfGuardedLogger implements Logger {
	
	private static final Log log = LogFactory.getLog(IfGuardedLogger.class);

	public void log(int arg1, int arg2, int arg3) {
		if (log.isDebugEnabled()) {
			log.debug("First argument = " + arg1 + ", second argument = " + arg2 + ", third argument = " + arg3);
		}
	}
}
