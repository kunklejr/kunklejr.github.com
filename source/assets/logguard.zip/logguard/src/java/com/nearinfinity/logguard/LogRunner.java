package com.nearinfinity.logguard;

import java.util.Random;

public class LogRunner {
	
	private static final int NUM_LOG_MESSAGES = 1000000;
	
	public static void main(String args[]) {
		LogRunner runner = new LogRunner();
		
		Logger unGuardedLogger = new UnguardedLogger();
		Logger ifGuardedLogger = new IfGuardedLogger();
		Logger aspectGuardedLogger = new AspectGuardedLogger();
		
		runner.run(NUM_LOG_MESSAGES, new Logger[]{unGuardedLogger, ifGuardedLogger, aspectGuardedLogger});
		runner.run(NUM_LOG_MESSAGES, new Logger[]{aspectGuardedLogger, unGuardedLogger, ifGuardedLogger});
		runner.run(NUM_LOG_MESSAGES, new Logger[]{ifGuardedLogger, aspectGuardedLogger, unGuardedLogger});
	}
	
	protected void run(int numLogMessages, Logger[] loggers) {
		String[] results = new String[loggers.length];
		for (int i = 0; i < loggers.length; i++) {
			Random randomGenerator = new Random();
			int random = randomGenerator.nextInt();
			long startTime = System.currentTimeMillis();
			for (int j = 0; j < numLogMessages; j++) {
				loggers[i].log((random + j), (random + j + 1), (random + j + 2));
			}
			long endTime = System.currentTimeMillis();
			results[i] = loggers[i].getClass().getSimpleName() + ": " + (endTime - startTime);
		}

		for (int i = 0; i < results.length; i++) {
			System.out.println(results[i]);
		}
		
	}
	
}
