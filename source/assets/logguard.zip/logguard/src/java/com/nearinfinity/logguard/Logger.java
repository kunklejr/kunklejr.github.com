package com.nearinfinity.logguard;

public interface Logger {

	public void log(int arg1, int arg2, int arg3);
	
}
